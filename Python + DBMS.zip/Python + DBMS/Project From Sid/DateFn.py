from datetime import date
x="2020-07-24"
print("Date started :",x)
datex = date.today()
print("Date today :", datex)
xdate="2020-12-21"
print("End date :",xdate)